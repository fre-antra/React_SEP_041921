# Personal-Website Evaluation

This is a evalutaion project sample. You need to migrate this project to a SPA using React.

## Requirements:

1. Undertand the current project's code, logic, and dependencies.
2. Design the React project architecture (reusable components, state, services, etc.);
3. Implement it using React with anything else you need.
4. Make it more responsive.
5. Write test cases for all the components and functions you have created.

## Submision: 

1. Submit (commit) your project by 6pm today (May 3 2021).
2. Submit your project using the Github link to Patrick using Slack.
3. Feel free to optimize your project even you have finished your submision.
