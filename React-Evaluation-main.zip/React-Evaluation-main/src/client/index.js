import React from 'react';
import ReactDOM from 'react-dom';
import './index.scss';

const App = () => <h1>You should see a red color text here</h1>;

ReactDOM.render(<App />, document.getElementById('root'));
